<?php
class stSocialCore{
     public  $icon_exts = array('png'); // 'icon','jpg','jpeg','gif' // png only
    
    function __construct(){
        $this->icons_dir = ST_SOCIAL_ICONS_PATH;
        $this->icons_url = ST_SOCIAL_ICONS_URL;
    }
    
    function get_nice_name($file,$number = false){
         $file = pathinfo($file);
         
         if($number==true){
                if(strpos($file['filename'],'-')!==false){
                 $file['filename'] = explode('-',$file['filename']);
                 $n = count($file['filename']);
                 if($n>1 && intval($file['filename'][$n-1]) > 0){
                      unset($file['filename'][$n-1]);
                 }
                 $file['filename'] = join($file['filename']);
              }
         }
         
         return  $file['filename'];
    }
    
    function id($file){
        return str_replace(array('.'),'-',$file);
    }
    
}


