jQuery(document).ready(function(){
    var icon_url = window.stsocial_url || '';
    
   jQuery('.quicksearch').quicksearch('.stsocial-list .ic', {
        'delay': 10,
        'selector': '.name',
     //   'stripeRows': ['odd', 'even'],
       // 'loader': 'span.loading',
       // 'noResults': 'tr#noresults',
       // 'bind': 'keyup keydown',
        'onBefore': function () {
           // console.log('on before');
        },
        'onAfter': function () {
           // console.log('on after');
        },
        'show': function () {
            jQuery(this).removeClass('icon_hide');
        },
        'hide': function () {
            jQuery(this).addClass('icon_hide');
        }
        
    });
    
    
    function  st_icon_live(v,p){
           var id = p.attr('id');
            if(v!=''){
 
                 if(jQuery('ul.st-icons li.'+id).length>0){
                     // icon added
                      jQuery('ul.st-icons li.'+id+' input').val(v);
                      jQuery('ul.st-icons li.'+id+' a').attr('href',v);
                 }else{
                        var icon =  jQuery('.sinput',p).attr('icon')
                        var icon =  jQuery('.sinput',p).attr('icon');
                        var size =  jQuery('.stsocial-form .icon_size').val();
                        var title = jQuery('.name',p).text();

                        var html ='<li  class="'+id+'" icon="'+icon+'"><input type="hidden" class="sort" name="stsocial_settings[social_sort]['+icon+']" value="" /><a href="" ><img src="'+icon_url+'/'+size+'/'+icon+'"></a></li>';
                       
                        jQuery('ul.st-icons').append(html);
                        
                         jQuery('ul.st-icons li.'+id+' input').val(v);
                         jQuery('ul.st-icons li.'+id+' a').attr('href',v);
                         jQuery('ul.st-icons li.'+id+' a').attr('title',title);
                         
                          var target = jQuery('.stsocial-form .link_target').val();
                            if(target!=''){
                                 jQuery('ul.st-icons li.'+id+' a').attr('target',target);
                            }
                         
                        
                 }
            }else{ // if empty
                jQuery('ul.st-icons li.'+id).remove();
            }
        
    }
    
     jQuery('.stsocial-list .ic .sinput').bind('keyup blur',function(){
        var v = jQuery(this).val();
        var  p =  jQuery(this).parents('.ic');
          st_icon_live(v,p);
        
     });
     
     jQuery('.stsocial-form .link_target').change(function(){
         var target = jQuery(this).val();   
            if(target!=''){
                 jQuery('ul.st-icons li a').attr('target',target);     
            }else{
                 jQuery('ul.st-icons li a').removeAttr('target');
            }
     });
     
     // when page load 
     /*
     jQuery('.stsocial-list .ic .sinput').each(function(){
            var v = jQuery(this).val();
            var  p =  jQuery(this).parents('.ic');
            st_icon_live(v,p);
     });
     */
     
     // when change size 
     jQuery('.stsocial-form .icon_size').change(function(){
           var size =  jQuery('.stsocial-form .icon_size').val();
           jQuery('.st-icons li').each(function(){
                var  p =  jQuery(this);
                 var icon =  p.attr('icon');
                 jQuery('a',p).html('<img src="'+icon_url+'/'+size+'/'+icon+'">')
            });
        
     });
     
     /* sort icon */
     jQuery('.st-icons').sortable({
            stop: function(event,ui){
            }
     });
     
     

    
    
});