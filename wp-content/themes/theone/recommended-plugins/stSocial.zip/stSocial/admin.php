<?php
class stSocialAdmin extends stSocialCore{
  
    public $icons_dir ;
    public $icons_url;
    public $icons; //
    public $list_size = '48x48';
    public $helps ;
    
    function __construct(){
        $this->icons_dir =ST_SOCIAL_ICONS_PATH;
        $this->icons_url = ST_SOCIAL_ICONS_URL;
        $this->setHelp();
    }
    
    function setHelp(){
        // 'icon_file_name' =>'help text'
        $this->helps = array(
			'behance.png' => 'e.g. http://www.behance.net/username',
			'blogger.png' => 'e.g. http://username.blogspot.com',
			'mail.png' => 'e.g. mailto:user@name.com',
			'delicious.png' => 'e.g. http://delicious.com/username',
			'deviantart.png' => 'e.g. http://username.deviantart.com/',
			'digg.png' => 'e.g. http://digg.com/username',
			'dopplr.png' => 'e.g. http://www.dopplr.com/traveller/username',
			'dribbble.png' => 'e.g. http://dribbble.com/username',
			'evernote.png' => 'e.g. http://www.evernote.com',
			'facebook.png' => 'e.g. http://www.facebook.com/username',
			'flickr.png' => 'e.g. http://www.flickr.com/photos/username',
			'forrst.png' => 'e.g. http://forrst.me/username',
			'github.png' => 'e.g. https://github.com/username',
			'google-plus.png' => 'e.g. http://plus.google.com/userid',
			'grooveshark.png' => 'e.g. http://grooveshark.com/username',
			'instagram.png' => 'e.g. http://instagr.am/p/picid',
			'lastfm.png' => 'e.g. http://www.last.fm/user/username',
			'linkedin.png' => 'e.g. http://www.linkedin.com/in/username',
			'myspace.png' => 'e.g. http://www.myspace.com/userid',
			'path.png' => 'e.g. https://path.com/p/picid',
			'paypal.png' => 'e.g. mailto:email@address',
			'picasa.png' => 'e.g. https://picasaweb.google.com/userid',
			'pinterest.png' => 'e.g. http://pinterest.com/username',
			'posterous.png' => 'e.g. http://username.posterous.com',
			'reddit.png' => 'e.g. http://www.reddit.com/user/username',
			'rss.png' => 'e.g. http://example.com/feed',
			'sharethis' => 'e.g. http://sharethis.com',
			'skype.png' => 'e.g. skype:username',
			'soundcloud.png' => 'e.g. http://soundcloud.com/username',
			'spotify.png' => 'e.g. http://open.spotify.com/user/username',
			'stumbleupon.png' => 'e.g. http://www.stumbleupon.com/stumbler/username',
			'tumblr.png' => 'e.g. http://username.tumblr.com',
			'twitter.png' => 'e.g. http://twitter.com/username',
			'viddler.png' => 'e.g. http://www.viddler.com/explore/username',
			'vimeo.png' => 'e.g. http://vimeo.com/username',
			'virb.png' => 'e.g. http://username.virb.com',
			'windows.png' => 'e.g. http://www.windows.com',
			'wordpress.png' => 'e.g. http://username.wordpress.com',
			'youtube.png' => 'e.g. http://www.youtube.com/user/username',
			'zerply.png' => 'e.g. http://zerply.com/username'
    	);
    }
    
    function getHelp($icon_file_name){
         return (isset($this->helps[$icon_file_name])) ?  $this->helps[$icon_file_name] : '' ;
    }
    
    function scanIcons($dir){
        $list_icons= array();
        if(is_readable($dir)){
            if ( $handle = opendir($dir)) {
                while (false !== ($entry = readdir($handle))) {
                    if ($entry != "." && $entry != "..") {
                        $info = wp_check_filetype( 'abc.png');
                        if($info['ext']!=''  && in_array($info['ext'],$this->icon_exts)){
                             $list_icons[$entry] = $entry;
                        }
                       
                    }
                }
                closedir($handle);
            }
        }

        return $list_icons;
    }


    function scanIconSizes(){
        if ($handle = opendir($this->icons_dir)) {
                while (false !== ($entry = readdir($handle))) {
                    if ($entry != "." && $entry != ".."  && is_dir($this->icons_dir.'/'.$entry)) {
                        $this->icons[$entry] =  '1';
                    }
                }
                closedir($handle);
        }
        
         if(isset($this->icons[$this->list_size]) ){
              $this->icons[$this->list_size] = $this->scanIcons($this->icons_dir.'/'.$this->list_size);
         }else{
               $icons =  current($this->icons);
               $key = key($this->icons);
               $this->icons[$key] = $this->scanIcons($this->icons_dir.'/'.$key);
         }
        
    }
    
    
    
    
    function display(){
        $msg = '';
        if(isset($_POST['save_change'])){
              update_option('stsocial', $_POST['stsocial']);
              update_option('stsocial_settings', $_POST['stsocial_settings']);
              $msg = '
              <div class="updated" id="message"><p>Your submit saved.</p></div>
              ';
        }
        
         $this->scanIconSizes();
         $icon_folder = '';
         if(isset($this->icons[$this->list_size]) ){
             $icons = $this->icons[$this->list_size];
             $icon_folder=  $this->list_size;
         }else{
              $icons =  current($this->icons);
              $icon_folder = key($this->icons);
         }
         
         $icon_url=  $this->icons_url.'/'.$icon_folder.'/';
         
         $stsocial = get_option('stsocial', array());
         $stsocial_settings =   get_option('stsocial_settings', array());
         if($stsocial_settings['icon_size']==''){
            $stsocial_settings['icon_size'] ='48x48';
         }
         
         
         ?>
         <script type="text/javascript">
              var stsocial_url = '<?php echo ST_SOCIAL_ICONS_URL ?>';
         </script>
          <div class="wrap">
            <div class="icon32" id="icon-options-general"><br></div>
            <h2>stSocial</h2>
            <?php echo $msg; ?>
            <div class="stleft">
            <div class="quicksearch-w">
                 <label>Quick Search:<input class="quicksearch" placeholder="Type social name..." /></label>
            </div>
            
             <form action="" class="stsocial-form" method="post">
            <div class="stsocial-list">
                <?php 
                 $i=1;
                
                    foreach($icons as $icon){
                           $name = $this->get_nice_name($icon);
                           $id=  $this->id($icon);
                           $help=  $this->getHelp($icon);
                          ?>
                          <div id="<?php echo $id; ?>" class="ic icon-w-<?php echo $i; ?>">
                              <div class="w">
                                 <span class="si">
                                 <img src="<?php echo $icon_url.$icon ?>" />
                                 </span>
                                 <div class="info">
                                     <input type="text" name="stsocial[<?php echo $icon; ?>]" value="<?php echo esc_attr($stsocial[$icon]) ; ?>" class="sinput" icon="<?php echo $icon; ?>" />
                                     <div class="txt" ><?php
                                     if($help!=''){
                                        printf('<b class="name display_none">%1$s</b>', ucfirst($name));  echo '<span class="help">'.$help.'</span>';
                                     }else{
                                        printf('<b class="name">%1$s</b> url, include <code>http://</code>', ucfirst($name));
                                     }
                                    ?></div>
                                 </div>
                                 <div class="clear"></div>
                              </div>
                          </div>
                          
                          <?php
                         if($i==2){
                            $i=1;
                         }else{
                            $i++;
                         }
                    }
                 ?>
                 <div class="clear"></div>
            </div>
            
            
             <div class="st_social_settings">
            <h3>Display Settings</h3>
            
                 <table>
                     <tr>
                         <td>Icon Size</td>
                         <td>
                             <select name="stsocial_settings[icon_size]"  class="icon_size">
                                 <?php
                                  foreach($this->icons as $k =>  $v): 
                                    if($stsocial_settings['icon_size']==$k){
                                          echo '<option value="'.$k.'" selected="selected">'.$k.'</option>';
                                    }else{
                                          echo '<option value="'.$k.'">'.$k.'</option>';
                                    }
                                  endforeach; 
                                 ?>
                             </select>
                         </td>
                     </tr>
                     
                     <tr>
                         <td>Link Target</td>
                         <td>
                             <select name="stsocial_settings[link_target]" class="link_target">
                                <option value="_blank">New window</option>
                                <option value="_top"  <?php echo ($stsocial_settings['link_target'] =='_top') ? ' selected="selected" ' : '';  ?> >Same window</option>
                             </select>
                             
                         </td>
                     </tr>
                     
                     <tr>
                         <td>Use rel</td>
                         <td>
                             <select name="stsocial_settings[uses_rel]" class="uses_rel">
                                <option value="nofollow">nofollow</option>
                                <option value="follow"  <?php echo ($stsocial_settings['uses_rel'] =='follow') ? ' selected="selected" ' : '';  ?> >follow</option>
                             </select>
                             
                         </td>
                     </tr>
                 
                 </table>
                 <strong>Preview:</strong><br />
                  <div class="st-s-preview">
                      <ul class="st-icons"> 
                           <?php
                           if(!is_array($stsocial_settings['social_sort'])){
                                 $stsocial_settings['social_sort'] = (array) $stsocial_settings['social_sort'];
                           }
                           
                            $link_target = ($stsocial_settings['link_target']!='') ?  ' target="'.esc_attr($stsocial_settings['link_target']).'" ' : '';
                           
                          // $stsocial_settings['social_sort'] = array();
                            foreach($stsocial_settings['social_sort'] as $icon=>$url){
                            
                              $name = $this->get_nice_name($icon);
                              $id=  $this->id($icon);
                              $src = ST_SOCIAL_ICONS_URL.'/'.$stsocial_settings['icon_size'].'/'.$icon;
                            ?>   
                          <li class="<?php echo $id; ?>" icon="<?php echo $icon; ?>">
                              <input class="sort" name="stsocial_settings[social_sort][<?php echo $icon ?>]" value="<?php echo esc_attr($url); ?>" type="hidden">
                              <a <?php echo $link_target; ?> title="<?php echo ucfirst($name); ?>" href="<?php echo esc_attr($url); ?>">
                              <img src="<?php echo $src; ?>"></a>
                          </li> 
                           <?php } ?>
                      </ul>
                  </div>
                 
                 <div class="clear"></div>
                 <p class="submit"><input type="submit" value="Save Changes" name="save_change" class="button-primary"></p>
          
            <h3>Usage</h3>
            <div class="usage">
                To use stSocial in your posts and pages you can use the shortcode:    <code>[st_social]</code> <br />
                To use stSocial manually in your theme template use the following PHP code: <br />
                <p><code> &lt;?php if( function_exists(&#39;st_social&#39;) ) st_social(); ?&gt; </code></p>
                You can optionally pass in a &quot;size&quot; and &quot;services&quot; parameter to both of the above to override the default values eg: <br />
                 <p> <code>[st_social size=&quot;16x16&quot; services=&quot;Twitter,Facebook,Google+&quot; link_target=&quot;_blank&quot; ]</code> </p>
                <p> <code> &lt;?php if( function_exists(&#39;st_social&#39;) ) st_social( &#39;16x16&#39;, array(&#39;Twitter&#39;,&#39;Facebook&#39;,&#39;Googleplus&#39;),'_blank' ); ?&gt;</code></p>
                
                <p>
                 <strong>Parameters:</strong><br />
                  size: name of folder icon size in folder <strong><?php echo ST_SOCIAL_ICONS_PATH; ?></strong>.<br />
                  services: name of services <?php ST_SOCIAL_ICONS_PATH; ?>.<br />
                </p>
            </div>
            
            </div>
            
            
            <div class="clear"></div>
            
              </form>
            </div><!--- stleft -->
            <div class="clear"></div>
            
          </div>
         <?php
    }
    
}