<?php
/*
Plugin Name: stSocial 
Plugin URI: http://www.smooththemes.com/
Description: A simple and easy way to add any Social Media profile in your theme.
Author: SmoothThemes
Version: 1.0
Author URI: http://smooththemes.com
*/

define('ST_SOCIAL_URL',plugins_url('/', __FILE__));
define('ST_SOCIAL_PATH',plugin_dir_path( __FILE__));
define('ST_SOCIAL_ICONS_URL',ST_SOCIAL_URL.'icons');
define('ST_SOCIAL_ICONS_PATH',ST_SOCIAL_PATH.'icons');

require_once (ST_SOCIAL_PATH.'core.php');
require_once (ST_SOCIAL_PATH.'admin.php');


add_action( 'admin_notices', 'st_social_admin_notice' );
function st_social_admin_notice(){
    if(is_readable(ST_SOCIAL_ICONS_PATH)){
        return;
    }
    // global $current_screen;
    echo '<div class="error"><p>'.sprintf(__('stSocial error: The folder %1$s  is not readable, Please CHMOD this folder to 775 or 777','stsocial'),ST_SOCIAL_ICONS_PATH).'</p></div>';    
}

add_action('admin_print_styles-toplevel_page_stsocial','st_social_admin_style');
function  st_social_admin_style(){
    wp_enqueue_style('stsocial',ST_SOCIAL_URL.'css/admin.css');
}

function st_social_admin_script(){
    wp_enqueue_script('jquery');
    wp_enqueue_script('jquery-ui-core');
    wp_enqueue_script('jquery-ui-slider');
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_script('quicksearch',ST_SOCIAL_URL.'js/quicksearch.js', array('jquery'));
    wp_enqueue_script('stsocial',ST_SOCIAL_URL.'js/admin.js', array('quicksearch'));
}

add_action('admin_print_scripts-toplevel_page_stsocial','st_social_admin_script');

function st_social_admin_menu(){
    $icon = '';
    add_menu_page('stSocial','stSocial','manage_options','stsocial','st_social_admin_display','');
}

// Function callback for add_menu_page
function st_social_admin_display(){
    $admin = new stSocialAdmin();
    $admin->display();
}
  
add_action('admin_menu','st_social_admin_menu');

function st_social_generate($size='',$services = array(), $link_target =''){
       $stsocial_settings =   get_option('stsocial_settings', array());
    
     //override services
      if(is_array($services) and count($services)){
           $tmpl_social = array();
            foreach($services as $k => $v){
                $icon = strtolower(trim($v));
                if(isset($stsocial_settings['social_sort'][$icon.'.png'])){
                     $tmpl_social[$icon.'.png'] = $stsocial_settings['social_sort'][$icon.'.png'];
                }
            }
            $stsocial_settings['social_sort'] = $tmpl_social;
      }
    
       if(!is_array($stsocial_settings['social_sort'])){
             $stsocial_settings['social_sort'] = (array) $stsocial_settings['social_sort'];
       }
       
       //override link target
       if($link_target!=''){
             $link_target =  ' target="'.esc_attr($link_target).'" ';
       }else{
             $link_target = ($stsocial_settings['link_target']!='') ?  ' target="'.esc_attr($stsocial_settings['link_target']).'" ' : ' target="_top" ';
       }
       

     $rel =  ($stsocial_settings['uses_rel']!='') ?  ' rel="'.esc_attr($stsocial_settings['uses_rel']).'" ' : ' rel="nofollow" ';
       
       
       $html ='';
       
       $icon_folder_url= '';
       $img_attr='';
       
       $s = new stSocialCore();      
        foreach($stsocial_settings['social_sort'] as $icon=>$url){
          $name = $s->get_nice_name($icon,true);
          $id=  $s->id($icon);
          if($icon_folder_url==''){
               if(isset($size)  && $size!='' && is_dir(ST_SOCIAL_ICONS_PATH.'/'.$size)){
                    $icon_folder_url = ST_SOCIAL_ICONS_URL.'/'.$size.'/';
               }else{
                    $icon_folder_url = ST_SOCIAL_ICONS_URL.'/'.$stsocial_settings['icon_size'].'/'.$size;
                    if($size!=''){
                        $size =  intval($size);
                        $img_attr =  ( intval($size) > 0 ) ? '  width="'.$size.'px" height="'.$size.'" ' : '';
                    }
               }
          }
          $src = $icon_folder_url.$icon;
          $html .=' <a  '.$link_target.$rel.' class="'.esc_attr($name).'" title="'.ucfirst($name).'" href="'.esc_attr($url).'"> <img '.$img_attr.' alt="" src="'.$src.'" /> </a>';
        }
        
        if($html!=''){
            $html = '<div class="st-social">'.$html.'</div>';
        }
      
      return $html;
}


function st_social_shorcode( $atts= array(), $content='' ) { 
    $atts = wp_parse_args($atts, array(
         'size' =>false,
         'services' =>  '',
         'link_target'=>''
    ));
    
    if($atts['services']!=''){
        $atts['services'] = explode(',',$atts['services']);
    }

    return st_social_generate($atts['size'],$atts['services'],$atts['link_target']);
    
}
add_shortcode( 'st_social', 'st_social_shorcode' );


// for static function 
function st_social($size='',$services = array(), $link_target ='', $display = true){
   $code=   st_social_generate($size,$services, $link_target);
   if($display){
      echo  $code;
      return '';
   }else{
        return $code;
   }
}

function st_social_wp_head(){
?>
<style type="text/css">
    .st-social a img{margin:0px 4px 4px 0px}
</style>
<?php
}

add_action('wp_head','st_social_wp_head');







